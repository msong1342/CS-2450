from UVSIM import read, write, load, store, add, subtract, divide, multiply, halt

def test_add():
    result = add(5, 10)
    if result == 15:
        print("test_add passed")
    else:
        print("test_add failed: expected 15, got", result)

    result = add(-5, 10)
    if result == 5:
        print("test_add_negative passed")
    else:
        print("test_add_negative failed: expected 5, got", result)

    result = add(0, 0)
    if result == 0:
        print("test_add_zero passed")
    else:
        print("test_add_zero failed: expected 0, got", result)

def test_subtract():
    result = subtract(10, 5)
    if result == 5:
        print("test_subtract passed")
    else:
        print("test_subtract failed: expected 5, got", result)

    result = subtract(-5, -5)
    if result == 0:
        print("test_subtract_negative passed")
    else:
        print("test_subtract_negative failed: expected 0, got", result)

    result = subtract(0, 0)
    if result == 0:
        print("test_subtract_zero passed")
    else:
        print("test_subtract_zero failed: expected 0, got", result)

def test_divide():
    result = divide(10, 2)
    if result == 5:
        print("test_divide passed")
    else:
        print("test_divide failed: expected 5, got", result)

    try:
        result = divide(10, 0)
        print("test_divide_by_zero failed: expected exception, got", result)
    except ZeroDivisionError:
        print("test_divide_by_zero passed")

def test_multiply():
    result = multiply(5, 2)
    if result == 10:
        print("test_multiply passed")
    else:
        print("test_multiply failed: expected 10, got", result)

    result = multiply(-5, 2)
    if result == -10:
        print("test_multiply_negative passed")
    else:
        print("test_multiply_negative failed: expected -10, got", result)

    result = multiply(0, 100)
    if result == 0:
        print("test_multiply_zero passed")
    else:
        print("test_multiply_zero failed: expected 0, got", result)

def test_store():
    accumulator = "+4321"
    result = store(accumulator)
    if ''.join(result) == '+4321':
        print("test_store passed")
    else:
        print("test_store failed: expected +4321, got", ''.join(result))

    accumulator = "-4321"
    result = store(accumulator)
    if ''.join(result) == '-4321':
        print("test_store_negative passed")
    else:
        print("test_store_negative failed: expected -4321, got", ''.join(result))

def test_load():
    registers = {f"{i:02}": ['+0000'] for i in range(100)}
    registers["02"] = list("+5678")
    result = load(registers, "02")
    if result == '+5678':
        print("test_load passed")
    else:
        print("test_load failed: expected +5678, got", result)

    registers["03"] = list("-1234")
    result = load(registers, "03")
    if result == '-1234':
        print("test_load_negative passed")
    else:
        print("test_load_negative failed: expected -1234, got", result)

def test_write():
    registers = {f"{i:02}": ['+0000'] for i in range(100)}
    registers["01"] = list("+1234")
    from io import StringIO
    import sys

    captured_output = StringIO()
    sys.stdout = captured_output
    try:
        write(registers, "01")
        sys.stdout = sys.__stdout__
        if captured_output.getvalue().strip() == '+1234':
            print("test_write passed")
        else:
            print("test_write failed: expected +1234, got", captured_output.getvalue().strip())
    finally:
        sys.stdout = sys.__stdout__

    registers["01"] = list("-1234")
    captured_output = StringIO()
    sys.stdout = captured_output
    try:
        write(registers, "01")
        sys.stdout = sys.__stdout__
        if captured_output.getvalue().strip() == '-1234':
            print("test_write_negative passed")
        else:
            print("test_write_negative failed: expected -1234, got", captured_output.getvalue().strip())
    finally:
        sys.stdout = sys.__stdout__

def test_halt():
    try:
        halt()
        print("test_halt failed: expected SystemExit")
    except SystemExit:
        print("test_halt passed")

def test_read():
    def mock_input(prompt):
        return '1234'

    original_input = __builtins__.input
    __builtins__.input = mock_input
    try:
        result = read()
        if result == '+1234':
            print("test_read_valid passed")
        else:
            print("test_read_valid failed: expected +1234, got", result)
    finally:
        __builtins__.input = original_input

    def mock_input_invalid(prompt):
        return 'abcd'

    __builtins__.input = mock_input_invalid
    try:
        read()
        print("test_read_invalid failed: expected ValueError")
    except ValueError:
        print("test_read_invalid passed")
    finally:
        __builtins__.input = original_input

def run_tests():
    test_add()
    test_subtract()
    test_divide()
    test_multiply()
    test_store()
    test_load()
    test_write()
    test_halt()
    test_read()

if __name__ == '__main__':
    run_tests()
