'''
Software Engineering
Milstone 2
Group I
UVSIM
'''


def read():
    '''Read a word from the keyboard into a specific location in memory. Return inputted number.'''
    num = input('Please input a 4 digit number: ')
    if not num.isdigit() or len(num) != 4:
        raise ValueError("Invalid input, expected a 4-digit number.")
    num = '+' + num
    return num


def write(registers, target):  # Caleb
    '''Write a word from a specific location in memory to screen'''
    if target not in registers:
        raise KeyError(f"Memory address {target} does not exist.")
    word = ''.join(registers[target])
    print(word)


def load(registers, target):  # Caleb
    '''Load a word from a specific location in memory into the accumulator.'''
    if target not in registers:
        raise KeyError(f"Memory address {target} does not exist.")
    word = ''.join(registers[target])
    return word


def store(accumulator):  # Caleb
    '''Store a word from the accumulator into a specific location in memory.'''
    word_string = f'{int(accumulator):+05d}'
    return list(word_string)


def add(accumulator, num):
    '''Add a word from a specific location in memory to the word in 
    the accumulator. Return the sum.'''
    added_num = int(accumulator) + int(num)
    return added_num


def subtract(accumulator, num):
    '''Subtract a word from a specific location in memory from the word 
    in the accumulator. Returns the difference.'''
    sub_num = int(accumulator) - int(num)
    return sub_num


def divide(accumulator, num):
    '''Divide the word in the accumulator by a word from a specific 
    location in memory. Returns the quotient.'''
    div_num = int(accumulator) / int(num)
    return div_num


def multiply(accumulator, num):
    '''Multiply a word from a specific location in memory to the word in 
    the accumulator. Return the product.'''
    mul_num = int(accumulator) * int(num)
    return mul_num


def halt():
    '''Stop and exit the program'''
    quit()


def load_file(registers):
    '''Loads a file. Takes as input a file name. Reads the file and returns 
    the registers.'''
    filename = input('Please enter file name: ')

    with open(filename, 'r') as file:
        lines = file.readlines()

    for i, line in enumerate(lines):
        number = line.strip()
        key = f'{i:02}'
        registers[key].extend(list(number))

    return registers


def main():
    '''Main function'''
    registers = {}
    for i in range(100):
        key = f"{i:02}"
        registers[key] = []

    registers = load_file(registers)

    # Creation of accumulator
    accumulator = 0
    # Creation of counter, to keep track of which register we are on.
    counter = 0

    while counter < len(registers):
        # Start with first register, run command
        command = ''.join(registers[f'{counter:02}'][1:3])
        target = ''.join(registers[f'{counter:02}'][3:])

        # print(command, target)

        match command:
            # ? I/O Operations
            case '10':
                res = read()
                registers[target] = res
            case '11':
                write(registers, target)
            # ? Load/Store Operations
            case '20':
                accumulator = load(registers, target)
            case '21':
                word = store(accumulator)
                registers[target] = word
            # ? Arithmetic Operations
            case '30':
                num = registers[target]
                accumulator = add(accumulator, num)
            case '31':
                num = registers[target]
                accumulator = subtract(accumulator, num)
            case '32':
                num = registers[target]
                accumulator = divide(accumulator, num)
            case '33':
                num = registers[target]
                accumulator = multiply(accumulator, num)
            # ? Control Operations
            case '40':
                counter = int(target)
                continue
            case '41':
                if accumulator < 0:
                    counter = int(target)
                    continue
            case '42':
                if accumulator == 0:
                    counter = int(target)
                    continue
            case '43':
                halt()
            case _:
                print('Error: invalid instruction')
                halt()

        counter += 1


if __name__ == '__main__':
    main()
